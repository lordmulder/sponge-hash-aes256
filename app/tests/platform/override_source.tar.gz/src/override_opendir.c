/*
 * SPDX-License-Identifier: Unlicense
 *
 * This software is released into the public domain.
 * See <https://unlicense.org/>
 */

#include "override.h"

// ---------------------------------------------------------------------------
// Initialization
// ---------------------------------------------------------------------------

typedef DIR*(opendir_fn)(const char*);
static opendir_fn *default_opendir = NULL;

static void init_routine(void)
{
    default_opendir = (opendir_fn*) dlsym(RTLD_NEXT, "opendir");
}

// ---------------------------------------------------------------------------
// opendir() override
// ---------------------------------------------------------------------------

DIR *opendir(const char *name)
{
    if ((!strcmp(name, "/proc/sys/kernel")) || (!strcmp(name, "/proc/sys/kernel/"))) {
        errno = EIO;
        return NULL;
    }

    initialize();

    if (default_opendir) {
        return default_opendir(name);
    } else {
        errno = ENOSYS;
        return NULL;
    }
}
