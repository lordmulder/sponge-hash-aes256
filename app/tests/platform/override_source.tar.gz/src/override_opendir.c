#define _GNU_SOURCE
#include <stdlib.h>
#include <errno.h>

void *opendir(const char *name)
{
    errno = EIO;
    return NULL;
}
