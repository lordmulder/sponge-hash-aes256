/*
 * SPDX-License-Identifier: Unlicense
 *
 * This software is released into the public domain.
 * See <https://unlicense.org/>
 */

#define _GNU_SOURCE
#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

// ---------------------------------------------------------------------------
// Initialization
// ---------------------------------------------------------------------------

typedef DIR*(opendir_fn)(const char*);
static pthread_once_t g_initialized = PTHREAD_ONCE_INIT;
static opendir_fn *default_opendir = NULL;

static void _my_init_routine(void)
{
    default_opendir = (opendir_fn*) dlsym(RTLD_NEXT, "opendir");
}

static void initialize(void)
{
    if (pthread_once(&g_initialized, _my_init_routine)) {
        abort();
    }
}

// ---------------------------------------------------------------------------
// opendir() override
// ---------------------------------------------------------------------------

DIR *opendir(const char *name)
{
    if ((!strcasecmp(name, "/proc/sys/kernel")) || (!strcasecmp(name, "/proc/sys/kernel/"))) {
        errno = EIO;
        return NULL;
    }

    initialize();

    if (default_opendir) {
        return default_opendir(name);
    } else {
        errno = ENOSYS;
        return NULL;
    }
}
