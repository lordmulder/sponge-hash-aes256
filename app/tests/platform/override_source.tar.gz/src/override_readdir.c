/*
 * SPDX-License-Identifier: Unlicense
 *
 * This software is released into the public domain.
 * See <https://unlicense.org/>
 */

#define GET_PATH_FROM_FD 1
#include "override.h"

// ---------------------------------------------------------------------------
// Initialization
// ---------------------------------------------------------------------------

typedef struct dirent* (readdir_fn)(DIR *dirp);
static readdir_fn *default_readdir = NULL;

typedef struct dirent64* (readdir64_fn)(DIR *dirp);
static readdir64_fn *default_readdir64 = NULL;

static void init_routine(void)
{
    default_readdir =   (readdir_fn*)   dlsym(RTLD_NEXT, "readdir");
    default_readdir64 = (readdir64_fn*) dlsym(RTLD_NEXT, "readdir64");
}

// ---------------------------------------------------------------------------
// readdir() override
// ---------------------------------------------------------------------------

struct dirent *readdir(DIR *dirp)
{
    char path[512];
    const int fd = dirfd(dirp);

    if ((fd >= 0) && (fd != STDIN_FILENO) && (fd != STDOUT_FILENO) && (fd != STDERR_FILENO)) {
        if (!get_path_from_fd(fd, path, 512)) {
            if ((!strcmp(path, "/proc/sys/kernel")) || (!strcmp(path, "/proc/sys/kernel/"))) {
                errno = EIO;
                return NULL;
            }
        }
    }

    initialize();

    if (default_readdir) {
        return default_readdir(dirp);
    } else {
        errno = ENOSYS;
        return NULL;
    }
}

struct dirent64 *readdir64(DIR *dirp)
{
    char path[512];
    const int fd = dirfd(dirp);

    if ((fd >= 0) && (fd != STDIN_FILENO) && (fd != STDOUT_FILENO) && (fd != STDERR_FILENO)) {
        if (!get_path_from_fd(fd, path, 512)) {
            if ((!strcmp(path, "/proc/sys/kernel")) || (!strcmp(path, "/proc/sys/kernel/"))) {
                errno = EIO;
                return NULL;
            }
        }
    }

    initialize();

    if (default_readdir64) {
        return default_readdir64(dirp);
    } else {
        errno = ENOSYS;
        return NULL;
    }
}
