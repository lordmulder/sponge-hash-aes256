#define _GNU_SOURCE
#include <stdlib.h>
#include <errno.h>

void *readdir(void *dirp)
{
    errno = EIO;
    return NULL;
}

void *readdir64(void *dirp)
{
    errno = EIO;
    return NULL;
}
