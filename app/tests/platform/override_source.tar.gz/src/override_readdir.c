/*
 * SPDX-License-Identifier: Unlicense
 *
 * This software is released into the public domain.
 * See <https://unlicense.org/>
 */

#define _GNU_SOURCE
#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

static const int g_sentinal_value;
#define SENTINAL_VALUE ((DIR*)&g_sentinal_value)

// ---------------------------------------------------------------------------
// Initialization
// ---------------------------------------------------------------------------

typedef DIR*(opendir_fn)(const char*);
typedef struct dirent* (readdir_fn)(DIR *dirp);
typedef struct dirent64* (readdir64_fn)(DIR *dirp);
typedef int (closedir_fn)(DIR *dirp);

static pthread_once_t g_initialized = PTHREAD_ONCE_INIT;
static opendir_fn *default_opendir = NULL;
static readdir_fn *default_readdir = NULL;
static readdir64_fn *default_readdir64 = NULL;
static closedir_fn *default_closedir = NULL;

static void _my_init_routine(void)
{
    default_opendir = (opendir_fn*) dlsym(RTLD_NEXT, "opendir");
    default_readdir = (readdir_fn*) dlsym(RTLD_NEXT, "readdir");
    default_readdir64 = (readdir64_fn*) dlsym(RTLD_NEXT, "readdir64");
    default_closedir = (closedir_fn*) dlsym(RTLD_NEXT, "closedir");
}

static void initialize(void)
{
    if (pthread_once(&g_initialized, _my_init_routine)) {
        abort();
    }
}

// ---------------------------------------------------------------------------
// opendir() override
// ---------------------------------------------------------------------------

DIR *opendir(const char *name)
{
    if ((!strcasecmp(name, "/proc/sys/kernel")) || (!strcasecmp(name, "/proc/sys/kernel/"))) {
        return SENTINAL_VALUE;
    }

    initialize();

    if (default_opendir) {
        return default_opendir(name);
    } else {
        errno = ENOSYS;
        return NULL;
    }
}

int closedir(DIR *dirp)
{
    if (dirp == SENTINAL_VALUE) {
        return 0;
    }

    initialize();

    if (default_closedir) {
        return default_closedir(dirp);
    } else {
        errno = ENOSYS;
        return -1;
    }
}

// ---------------------------------------------------------------------------
// readdir() override
// ---------------------------------------------------------------------------

struct dirent *readdir(DIR *dirp)
{
    if (dirp == SENTINAL_VALUE) {
        errno = EIO;
        return NULL;
    }

    initialize();

    if (default_readdir) {
        return default_readdir(dirp);
    } else {
        errno = ENOSYS;
        return NULL;
    }
}

struct dirent64 *readdir64(DIR *dirp)
{
    if (dirp == SENTINAL_VALUE) {
        errno = EIO;
        return NULL;
    }

    initialize();

    if (default_readdir64) {
        return default_readdir64(dirp);
    } else {
        errno = ENOSYS;
        return NULL;
    }
}
