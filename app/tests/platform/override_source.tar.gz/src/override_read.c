/*
 * SPDX-License-Identifier: Unlicense
 *
 * This software is released into the public domain.
 * See <https://unlicense.org/>
 */

#define GET_PATH_FROM_FD 1
#include "override.h"

// ---------------------------------------------------------------------------
// Initialization
// ---------------------------------------------------------------------------

typedef ssize_t (read_fn)(int, void*, size_t);
static read_fn *default_read = NULL;

static void init_routine(void)
{
    default_read = (read_fn*) dlsym(RTLD_NEXT, "read");
}

// ---------------------------------------------------------------------------
// read() override
// ---------------------------------------------------------------------------

ssize_t read(int fd, void *buf, size_t count)
{
    char path[512];

    if ((fd >= 0) && (fd != STDIN_FILENO) && (fd != STDOUT_FILENO) && (fd != STDERR_FILENO)) {
        if (!get_path_from_fd(fd, path, 512)) {
            if (!strcmp(path, "/proc/sys/kernel/version")) {
                errno = EIO;
                return -1;
            }
        }
    }

    initialize();

    if (default_read) {
        return default_read(fd, buf, count);
    } else {
        errno = ENOSYS;
        return -1;
    }
}
