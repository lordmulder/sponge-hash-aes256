#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// ---------------------------------------------------------------------------
// Utility functions
// ---------------------------------------------------------------------------

typedef ssize_t (read_fn)(int, void*, size_t);
static read_fn *__read_addr = NULL;
static pthread_once_t __read_init_flag = PTHREAD_ONCE_INIT;

static void __init_read_addr(void)
{
    __read_addr = (read_fn*) dlsym(RTLD_NEXT, "read");
}

static read_fn *get_read_addr(void)
{
    if (pthread_once(&__read_init_flag, __init_read_addr)) {
        abort();
    }

    return __read_addr;
}

static int get_path_from_fd(int fd, char *path_out, size_t capacity)
{
    char proc_fd[40];
    ssize_t len;
    sprintf(proc_fd, "/proc/self/fd/%d", fd);

    len = readlink(proc_fd, path_out, capacity);
    if ((len > 0) && (len < capacity)) {
        path_out[len] = '\0';
        return 0;
    }

    return -1;
}

// ---------------------------------------------------------------------------
// read() override
// ---------------------------------------------------------------------------

ssize_t read(int fd, void *buf, size_t count)
{
    char path[512];
    read_fn *read_addr;

    if ((fd != STDIN_FILENO) && (fd != STDOUT_FILENO) && (fd != STDERR_FILENO)) {
        if (!get_path_from_fd(fd, path, 512)) {
            if (!strcasecmp(path, "/proc/version")) {
                errno = EIO;
                return -1;
            }
        }
    }

    if (!(read_addr = get_read_addr())) {
        errno = ENOSYS;
        return -1;
    }

    return read_addr(fd, buf, count);
}
