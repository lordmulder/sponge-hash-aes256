/*
 * SPDX-License-Identifier: Unlicense
 *
 * This software is released into the public domain.
 * See <https://unlicense.org/>
 */

#define _GNU_SOURCE
#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

// ---------------------------------------------------------------------------
// Initialization
// ---------------------------------------------------------------------------

typedef ssize_t (read_fn)(int, void*, size_t);
static read_fn *default_read = NULL;
static pthread_once_t g_initialized = PTHREAD_ONCE_INIT;

static void _my_init_routine(void)
{
    default_read = (read_fn*) dlsym(RTLD_NEXT, "read");
}

static void initialize(void)
{
    if (pthread_once(&g_initialized, _my_init_routine)) {
        abort();
    }
}

// ---------------------------------------------------------------------------
// Get path from FD
// ---------------------------------------------------------------------------

static int get_path_from_fd(int fd, char *path_out, size_t capacity)
{
    char proc_fd[40];
    ssize_t len;
    sprintf(proc_fd, "/proc/self/fd/%d", fd);

    len = readlink(proc_fd, path_out, capacity);
    if ((len > 0) && (len < capacity)) {
        path_out[len] = '\0';
        return 0;
    }

    return -1;
}

// ---------------------------------------------------------------------------
// read() override
// ---------------------------------------------------------------------------

ssize_t read(int fd, void *buf, size_t count)
{
    char path[512];

    if ((fd != STDIN_FILENO) && (fd != STDOUT_FILENO) && (fd != STDERR_FILENO)) {
        if (!get_path_from_fd(fd, path, 512)) {
            if (!strcasecmp(path, "/proc/version")) {
                errno = EIO;
                return -1;
            }
        }
    }

    initialize();

    if (default_read) {
        return default_read(fd, buf, count);
    } else {
        errno = ENOSYS;
        return -1;
    }
}
