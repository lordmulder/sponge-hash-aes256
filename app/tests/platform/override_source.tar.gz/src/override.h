/*
 * SPDX-License-Identifier: Unlicense
 *
 * This software is released into the public domain.
 * See <https://unlicense.org/>
 */

#define _GNU_SOURCE
#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

// ---------------------------------------------------------------------------
// Initialization
// ---------------------------------------------------------------------------

static void init_routine(void);

static pthread_once_t g_initialized = PTHREAD_ONCE_INIT;

static void initialize(void)
{
    if (pthread_once(&g_initialized, init_routine)) {
        abort();
    }
}

// ---------------------------------------------------------------------------
// Get path from FD
// ---------------------------------------------------------------------------

#ifdef GET_PATH_FROM_FD

static int get_path_from_fd(int fd, char *path_out, size_t capacity)
{
    char proc_fd[40];
    ssize_t len;
    sprintf(proc_fd, "/proc/self/fd/%d", fd);

    len = readlink(proc_fd, path_out, capacity);
    if ((len > 0) && (len < capacity)) {
        path_out[len] = '\0';
        return 0;
    }

    return -1;
}

#endif /* _GET_PATH_FROM_FD */
