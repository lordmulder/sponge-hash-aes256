/*
 * SPDX-License-Identifier: Unlicense
 *
 * This software is released into the public domain.
 * See <https://unlicense.org/>
 */

#define _GNU_SOURCE
#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

/* ------------------------------------------------------------------------- */
/* Initialization                                                            */
/* ------------------------------------------------------------------------- */

static void set_up(void);
static pthread_once_t g_initialized = PTHREAD_ONCE_INIT;

static void initialize(void)
{
    if (pthread_once(&g_initialized, set_up)) {
        abort();
    }
}

/* ------------------------------------------------------------------------- */
/* Get path from FD                                                          */
/* ------------------------------------------------------------------------- */

#ifdef GET_PATH_FROM_FD

static void _uitoa(unsigned n, char *s)
{
    char *t = s;

    do {
        *t++ = '0' + (n % 10);
    } while ((n /= 10));

    *t-- = '\0';

    while (s < t) {
        const char _x = *s;
        *s++ = *t;
        *t-- = _x;
    }
}

static int get_path_from_fd(const int fd, char *const path_out, const size_t capacity)
{
    ssize_t len;
    char proc_fd[64] = { '/', 'p', 'r', 'o', 'c', '/', 's', 'e', 'l', 'f', '/', 'f', 'd', '/' };

    if (fd >= 0) {
        _uitoa(fd, proc_fd + 14);
        len = readlink(proc_fd, path_out, capacity);
        if ((len > 0) && ((size_t)len < capacity)) {
            path_out[len] = '\0';
            return 0;
        }
    }

    return -1;
}

#endif /* GET_PATH_FROM_FD */
