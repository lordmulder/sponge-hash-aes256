#!/bin/bash
set -e

cd -- "$(dirname -- "$(readlink -f -- "${BASH_SOURCE[0]}")")"
mkdir -p out

readonly IMAGE_ID="b972943e49a34a1aab738b59e12c5d0a"

for p in amd64 386 arm64; do
	docker buildx build --platform "${p}" --no-cache -t "${IMAGE_ID}-${p}" .
	docker run --rm --platform "${p}" -v ./src:/work:ro -v ./out:/var/tmp/out -w /work "${IMAGE_ID}-${p}" make -B CC=gcc OUT_PATH=/var/tmp/out
done
