#!/bin/bash
set -e
readonly IMAGE_UUID="$(cat /proc/sys/kernel/random/uuid)"

for p in amd64 386 arm64; do
    docker buildx build --platform "${p}" --no-cache -t "${IMAGE_UUID}-${p}" .
    docker run --rm --platform "${p}" -v ./src:/work:ro -v ./out:/var/tmp/out -w /work "${IMAGE_UUID}-${p}" make -B OUT_PATH=/var/tmp/out
done
